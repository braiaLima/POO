package Ponto2D;

public class Ponto3D extends Ponto2D {
    private double z;

    public Ponto3D(double x, double y, double z) {
        super(x, y);
        this.z = z;
    }

    public Ponto3D() {
        super();
        this.z = 0;
    }

    public double getZ() {
        return this.z;
    }

    public void desl(double x, double y, double z) {
        super.desl(x, y);
        this.z += z;
    }

    public Ponto3D somaP(double x, double y, double z) {
        return new Ponto3D(super.getX() + x, super.getY() + y, this.z + z);
    }

    public Ponto3D somaP(Ponto3D p) {
        return new Ponto3D(super.getX() + p.getX(), super.getY() + p.getY(), this.z + p.getZ());
    }

    public String toString() {
        return super.toString() + "\nponto Z:" + this.z + "\n";
    }

    public Ponto3D clone() {
        return new Ponto3D(super.getX(), super.getY(), getZ());
    }
}
