package Ponto2D;

import Ponto2D.Ponto2D;

public class Pixel extends Ponto2D {
    private int cor;

    public Pixel(int cor, double x, double y) {
        super(x, y);
        this.cor = cor % 100;
    }

    public Pixel() {
        super();
        this.cor = 0;
    }

    public int getCor() {
        return cor;
    }

    public void mudaCor(int cor) {
        this.cor = cor;
    }

    public void deslocaPixel(double x, double y) {
        super.desl(x, y);
    }

    public String toString() {
        return super.toString() + "\n Cor: " + cor+ "\n";
    }

    public Pixel clone(){return new Pixel(getCor(), super.getX(), super.getY());}

}
