import Ponto2D.Pixel;
import Ponto2D.Ponto2D;
import Ponto2D.Ponto3D;

public class TestePonto {
    public static void main(String[] args) {
        Ponto2D p2D = new Ponto2D(2, 3);
        Ponto3D p3D = new Ponto3D(1, 2, 3);
        Ponto3D p3d2 = new Ponto3D(1, 2, 3);
        Pixel p = new Pixel(2, 3, 4);

        System.out.println(p);
        p.desl(-3, 2);
        System.out.println(p);

        System.out.println(p3D);
        p3D.desl(2, 3, 4);
        System.out.println(p3D);

        System.out.println(p3d2);
        p3d2 = p3d2.somaP(p3D);
        System.out.println(p3d2);

        System.out.println(p2D);
        p2D.desl(2, 4);
        System.out.println(p2D);
    }
}