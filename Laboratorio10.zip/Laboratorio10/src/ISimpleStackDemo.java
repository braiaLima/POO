
public class ISimpleStackDemo {

	public static void main(String[] args) {
		ISimpleStack fixed = new FixedLengthStack(5);
		ISimpleStack dynamic = new DynamicStack(5);
		
		
	}
	
}
